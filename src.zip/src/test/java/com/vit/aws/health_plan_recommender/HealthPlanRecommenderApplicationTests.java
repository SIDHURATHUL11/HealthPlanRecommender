package com.vit.aws.health_plan_recommender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthPlanRecommenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
