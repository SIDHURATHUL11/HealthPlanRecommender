package com.vit.aws.health_plan_recommender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthPlanRecommenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthPlanRecommenderApplication.class, args);
	}

}
