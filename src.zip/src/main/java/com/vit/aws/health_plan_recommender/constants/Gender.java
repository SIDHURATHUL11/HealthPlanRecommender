package com.vit.aws.health_plan_recommender.constants;

public enum Gender {

    Male, Female;
}
